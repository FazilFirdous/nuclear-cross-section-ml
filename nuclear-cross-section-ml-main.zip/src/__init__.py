"""
Nuclear cross-section prediction using machine learning.

This package provides tools for downloading, processing, and modeling
neutron cross-section data from EXFOR and ENDF evaluated libraries.
"""

__version__ = "0.1.0"
__author__ = "Fazil Firdous"
